/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
public class Student {
    public int age;
    public String name;
    public String regno;
    public static String school = "JKUAT IHM";
    public static void main(String[] args){
        Student std1 = new Student();
        Student std2 = new Student();
        std1.age = 21;
        std1.name = "Kamaru";
        std1.regno = "IHM130/2017";
        std1.school = "Kapienga";
        std1.age = 23;
        std2.name = "Ayieko";
        std2.regno = "IHM0101/2017";
        
        Student.school = "Shimo la tewa";
        System.out.println("Student 1 details");
        System.out.println("Name : "+std1.name+"\nReg No : "+std1.regno+"\nAge : "+std1.age+"\nSchool : "+std1.school);
        System.out.println("\nStudent 2 details");
        System.out.println("Name : "+std2.name+"\nReg No : "+std2.regno+"\nAge : "+std2.age+"\nSchool : "+std2.school);
    }
}
