/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.util.*;

public class Fruits {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int fruits, dozen = 100;
        double cost = 0;
        System.out.println("Enter total number of fruits");
        fruits = input.nextInt();
        if (fruits >= 12) {
            do {
                cost = cost + dozen;
                fruits = fruits - 12;
            } while (fruits >= 12);
            cost = cost + (fruits * 10);
        } else {
            cost = fruits * 10;
        }
        System.out.println("Total cost = " + cost);
    }
}
