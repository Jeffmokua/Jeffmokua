/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MetDep;

import java.util.*;
/**
 *
 * @author dylo
 */
import java.util.*;

public class Met {

    /*Scanner met=new Scanner(System.in);

     public static void main(String[] args) {
     double average,sum;
     String[]name=new String[7];
     int[][]reading=new int[6][2];
       
       
     }
     }*/
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int mor, mid, ev;
        double dayav, wkav, value;
        String day;
        int i = 0, col, row;
        System.out.println("Enter the day, and the corresponding morning, midday and evening readings respectfully");
        for (row = 0; row <= 6; row++) {
            System.out.print("Day: ");
            day = input.next();
            for (col = 0; col <= 2; col++) {
                value = input.nextDouble();

            }

        }

    }
}
