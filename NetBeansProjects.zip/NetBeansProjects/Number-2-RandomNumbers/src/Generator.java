
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author dylo
 */
public class Generator {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int i;
        int countscore = 0;

        /*
        while (i < 5) {

            int a = (int) System.currentTimeMillis() % 7;
            int b = (int) System.currentTimeMillis() % 10;
            int total = a * b;
            System.out.print(a + " * " + b + " = ");
            int sum = input.nextInt();

            //System.out.println("Correct answer is " + total);
            //System.out.println("You gave the answer " + sum);
            System.out.println(total == sum);

            if (total == sum) {
                countscore++;
            }

            i++;

        }
        
         */
 /*        
        do {

            int a = (int) System.currentTimeMillis() % 7;
            int b = (int) System.currentTimeMillis() % 10;
            int total = a + b;
            System.out.print(a + " + " + b + " = ");
            int sum = input.nextInt();

            //System.out.println("Correct answer is " + total);
            //System.out.println("You gave the answer " + sum);
            System.out.println(total == sum);

            if (total == sum) {
                countscore++;
            }
            
            i++;
            
        } while (i < 5);
         */
        for (i = 0; i < 5; i++) {

            int a = (int) System.currentTimeMillis() % 7;
            int b = (int) System.currentTimeMillis() % 10;
            int total = a + b;
            System.out.print("\n" + a + " + " + b + " = ");
            int sum = input.nextInt();
            System.out.println(total == sum);
            System.out.println("Correct answer is " + total);
            System.out.println("You gave the answer " + sum);

            if (total == sum) {
                countscore++;
            }

        }

        System.out.println("Your total score is " + countscore + "/" + i);
    }

}
