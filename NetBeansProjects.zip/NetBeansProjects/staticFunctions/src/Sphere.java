/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.util.*;
import javax.swing.JOptionPane;
public class Sphere {
    public static double radius, volume;
  //  Scanner sc = new Scanner(System.in);
    public static void getdetails(){
        System.out.println("Enter the radius of sphere");
        radius = Double.parseDouble(JOptionPane.showInputDialog("Enter radius"));
    }
    public static void compute(){
        volume = (4/3)*Math.PI*Math.pow(radius, 3);
    }
    public static void print(){
        //System.out.println("Volume = "+volume);
        JOptionPane.showMessageDialog(null, "Volume = "+volume);
    }
    
}
