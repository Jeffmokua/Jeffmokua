/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.util.*;
public class DetermineDay {
    public static void main(String[] args){
        int h,q,m,k,year;
        int j = 0;
        Scanner input = new Scanner (System.in);
        System.out.println("Enter day of month");
        q = input.nextInt();
        System.out.println("Enter the month \n 3 - March, 4 - April, 5 - May, bla bla bla..");
        m = input.nextInt();
        System.out.println("Enter Year of the century");
        k = input.nextInt();
        h = (q+(int)(26*(m+1)/10)+k+(int)k/4+(int)j/4+5*j)%7;
        System.out.println("h = "+h);
        if (h == 0){
            System.out.println("Saturday");
        }
        else if (h == 1){
            System.out.println("Sunday");
        }
        else if (h == 2){
            System.out.println("Monday");
        }
        else if (h == 3){
            System.out.println("Tuesday");
        }
        else if (h == 4){
            System.out.println("Wednesday");
        }
        else if (h == 5){
            System.out.println("Thursday");
        }
        else {
            System.out.println("Friday");
        }
    }
}
