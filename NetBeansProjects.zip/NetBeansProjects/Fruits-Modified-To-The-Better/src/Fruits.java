/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
//import java.io.PrintStream;
import java.util.*;
import javax.swing.JOptionPane;

public class Fruits {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int fruits = 1, dozen = 100;
        double cost = 0, discount, rate = 0;
        double cash, balance = 0;
        boolean proceed = true;
        System.out.println("This Program is modified to give discounts");
        System.out.println("Enter total number of fruits");
        fruits = input.nextInt();

        //testing out the dozen charge
        if (fruits >= 12) { //first it checks if the total number of fruits can form a dozen. if so;

            //do {
            //cost = cost + dozen; //adds 100, which is the cost of a dozen to the total cost
            //fruits = fruits - 12; //it subtracts the just computed dozen from the rest
            //} while (fruits >= 12); //checks if the number of fruits remaining still form a dozen. if so, it will keep on charging 100 for as long as there is at least a dozen left
            //for (fruits = 1; fruits >= 12; fruits++) {
            //cost = cost + dozen;
            //fruits = fruits - 12;
            //}
            while (fruits >= 12) { //checks if the number of fruits form a dozen. if so, it will keep on charging 100 for as long as there is at least a dozen left
                cost = cost + dozen; //adds 100, which is the cost of a dozen to the total cost
                fruits = fruits - 12; //it subtracts the just computed dozen from the rest
            }

            cost = cost + (fruits * 10); //when the number of fruits left falls below the dozen mark, it sums up their costs individually then adds them to the rest
        } else { //if the total number of fruits can't form a dozen; 
            cost = fruits * 10; //it just multiplies their number by 10 to find the total cost
        }

        //discount section
        if (cost >= 500) {
            rate = 0.05;
        } else if (cost > 750) {
            rate = 0.08;
        } else if (cost > 1000) {
            rate = 0.1;
        } else if (cost > 1500) {
            rate = 0.15;
        }
        discount = cost * rate;
        if (cost <= 500) {
            System.out.println("Cost = " + cost);
            System.out.println("Sorry. No discount for fruits worth less thsn Ksh. 500");
        } else {
            System.out.println("Cost = " + cost);
            System.out.println("Your discount for this purchase = " + discount);
            cost = cost - discount;
            System.out.println("Payable Cost = " + cost+" after discount");
        }
        try {
            System.out.print("Cash : ");
            cash = input.nextDouble();
            if (cash > cost) {
                balance = cash - cost;
                System.out.println("Balance = " + balance);
            } else {
                System.out.println("Cash given cannot be less than cost");
            }
        } catch (ArithmeticException ex1) {
            System.out.println("Cash cannot be less than cost");
        }
        finally{
            System.out.println("This Software Rocks!");
        }

        /*try{
         cash = input.nextDouble();
         balance =  cash - cost;
         System.out.println("Balance = "+balance);
         proceed = false;
         } catch(ArithmeticException ex1){
         System.out.println(ex1);
         System.out.println("Cash given cannot be less than cost");
         }
         */
    }
}
