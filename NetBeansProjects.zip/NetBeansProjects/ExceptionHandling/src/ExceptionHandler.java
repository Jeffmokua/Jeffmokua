
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
public class ExceptionHandler {
    public static void main(String[] args){
        boolean proceed = true;
        int a, b, output;
        do {
            try{
                a = Integer.parseInt(JOptionPane.showInputDialog(null,"Enter the first value"));
                b = Integer.parseInt(JOptionPane.showInputDialog(null,"Enter the second value"));
                output = a/b;
                System.out.println("Output = "+output);
                proceed = false;
            } catch(ArithmeticException ex1){
                System.out.println(ex1);
                System.out.println("Enter value other than a 0 for the denominator");
            } catch(NumberFormatException ex2){
                System.out.println(ex2);
                System.out.println("Enter Integer values only");
            }
            finally{
                System.out.println("Hi there");
            }
        }while (proceed);
    }
}
