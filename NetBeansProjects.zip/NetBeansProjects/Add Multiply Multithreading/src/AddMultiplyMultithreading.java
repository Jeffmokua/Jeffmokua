/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.util.*;

public class AddMultiplyMultithreading extends Thread {

    String threadname;

    public AddMultiplyMultithreading(String name) {
        threadname = name;
        System.out.println(threadname + " has been Created");
    }

    public void run() {
        Scanner input = new Scanner(System.in);
        System.out.println(threadname + " has Started");
        int a = 0, b = 0;
        double multi = 0, add = 0;
        System.out.println("Enter two integer values");
        System.out.print("a : ");
        a = input.nextInt();
        System.out.print("b : ");
        b = input.nextInt();
        try {
            for (int i = 3; i > 0; i--) {
                System.out.println(threadname + " is Running " + i);
                multi = a * b;
                add = a + b;
                System.out.println("Integers Multiplied = " + multi);
                System.out.println("Integers Added = " + add);
                System.out.println(threadname + " is Sleeping");
                Thread.sleep(500);
                System.out.println(threadname + " has risen");
            }
        } catch (InterruptedException ex1) {
            System.out.println(threadname + " is Interrupted");
        }
        System.out.println(threadname + " has been Terminated");
    }

    public static void main(String[] args) {
        AddMultiplyMultithreading t1 = new AddMultiplyMultithreading("Addition Thread");
        AddMultiplyMultithreading t2 = new AddMultiplyMultithreading("Multiplication Thread");
        t1.start();
        t2.start();
    }
}
