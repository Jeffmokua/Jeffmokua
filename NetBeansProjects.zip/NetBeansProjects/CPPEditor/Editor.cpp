#include<iostream>
using namespace std;

int small(int x, int y, int z);

int main() {

    int a, b, c, sm;
    cout << "Enter the three integers" << endl;
    cin >> a >> b>>c;
    sm = small(a, b, c);
    cout << "Smallest Integer = " << sm;

    return 0;
}

int small(int x, int y, int z) {
    int less;

    if (x < y && x < z) {
        less = x;
    } else if (y < x && y < z) {
        less = y;
    } else if (z < x && z < y) {
        less = z;
    }

    return less;
}