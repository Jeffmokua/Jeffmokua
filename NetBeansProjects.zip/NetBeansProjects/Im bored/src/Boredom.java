/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import javax.swing.JOptionPane;

public class Boredom {

    public static void main(String[] args) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Boredom.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        int n = 1;
        while (n > 0) {
            System.out.print(n + " ");
            n += 1;
            JOptionPane.showMessageDialog(null, "DO NOT CLOSE THIS MESSAGE!.", "DOOMS DAY!!!", JOptionPane.INFORMATION_MESSAGE);
        }
        if (n == 2) {
            JOptionPane.showMessageDialog(null, "I'M WARNING YOU, DON'T CLOSE IT!.", "DOOMS DAY!!!", JOptionPane.INFORMATION_MESSAGE);
        } else if (n == 3) {
            JOptionPane.showMessageDialog(null, "LAST WARNING!", "DOOMS DAY!!!", JOptionPane.INFORMATION_MESSAGE);
        } else if (n == 4) {
            JOptionPane.showMessageDialog(null, "You did not heed. A malware that can't be undone has been installed in your PC.", "DOOMS DAY!!!", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
