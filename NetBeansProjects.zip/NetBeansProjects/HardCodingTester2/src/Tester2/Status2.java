/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tester2;

/**
 *
 * @author dylo
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.FlowLayout;
import javax.swing.*;

public class Status2 extends JFrame {

    private final JLabel lbl4;
    private final JLabel lbl5;
    private final JTextField txtdiastolic;
    private final JTextField txtsystolic;
    private final JButton btnstatus;
    private final JLabel lbl6;

    public Status2() {
        super("BP STATUS SCREEN");
        setLayout(new FlowLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1050, 650);
        setVisible(true);
        lbl4 = new JLabel("Diastolic");
        add(lbl4);
        txtdiastolic = new JTextField(10);
        add(txtdiastolic);
        lbl5 = new JLabel("Systolic");
        add(lbl5);
        txtsystolic = new JTextField(10);
        add(txtsystolic);
        btnstatus = new JButton("BP Status");
        add(btnstatus);
        lbl6 = new JLabel();
        add(lbl6);

        Check2 ck2 = new Check2();
        btnstatus.addActionListener(ck2);

    }

    private class Check2 implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {

            if (event.getSource() == btnstatus) {
                double dia, sys;
                String status;
                sys = Double.parseDouble(txtsystolic.getText());
                dia = Double.parseDouble(txtdiastolic.getText());
                if (sys < 120 && dia < 80) {
                    status = "Normal";
                } else if (sys < 140 && dia < 90) {
                    status = "Hypertension";
                } else {
                    status = "High";
                }
                lbl6.setText("BP Status: " + status);
            }
        }
    }
}
