
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author dylo
 */
import java.util.*;

public class Sales {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double[] ar;
        double sales = 0;
        int counter = 0;
        int total = 0;
        ar = new double[10];
        String day, name = null;

        do {
            System.out.println("Enter name of salesman " + (counter + 1));
            name = input.next();
            for (counter = 0; counter < 10; counter++) {
                System.out.print("Enter sales " + (counter + 1) + " ");
                sales = input.nextDouble();
            }
        } while (counter < 5);

        for (counter = 0; counter < 5; counter++) {
            System.out.println("Enter day" + (counter + 1));
            day = input.next();

            for (counter = 0; counter < 5; counter++) {

                total += ar[counter];
                System.out.println("name=" + name + "\nday=" + day + "\nsales=" + sales + (counter + 1));
            }
        }
    }
}
