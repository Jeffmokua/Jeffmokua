/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */

/*

 reading = sales
 sitename = man

 */
import java.util.*;

public class SalesMen {

    private String salesman;
    private int[][] sales;

    public SalesMen(String man, int[][] salesArray) {
        salesman = man;
        sales = salesArray;
    }

    public void processsales() {
        //printme();
        //System.out.printf("\n%s %d\n%s%d\n\n", "lowestreading in metelologist is", getminimum(), "highest reading is", getmaximum());
        //outputform();
    }

    public int getsales(int sale) {
        Scanner input = new Scanner(System.in);
        for (int[] daysales : sales) {
            //for (int sale  : daysales) {
            sale = input.nextInt();
        }
        //}
        return sale;
    }

}
