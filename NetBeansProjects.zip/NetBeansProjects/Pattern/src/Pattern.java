/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
public class Pattern {

    public static void main(String[] args) {
        int row = 1, col = 1;
        System.out.println("out");
        do {

            do {

                System.out.print(col + " ");
                col++;
            } while (col <= 5);
            /*for(col=1;col<=row;col++){
             System.out.print(col+" ");*/

            row++;
        } while (row <= 5);
        System.out.println();
        /*
         for(row=1;row<=5;row++){
         for(col=1;col<=row;col++){
         System.out.print(col+" ");
         }
         System.out.println();
         }*/
    }
}
