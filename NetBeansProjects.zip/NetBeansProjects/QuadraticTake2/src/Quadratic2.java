/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.util.*;

public class Quadratic2 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int a, b, c, x;
        System.out.println("Enter values of a, b, and c respectively");
        System.out.print("a : ");
        a = input.nextInt();
        System.out.print("b : ");
        b = input.nextInt();
        System.out.print("c : ");
        c = input.nextInt();
        x = (-b + (int) Math.sqrt(Math.pow(b, 2) - 4 * a * c)) / (2 * a);
        System.out.println("Discriminant = " + x);
    }
}
