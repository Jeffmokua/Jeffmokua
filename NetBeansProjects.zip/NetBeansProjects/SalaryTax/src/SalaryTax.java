/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.util.*;
public class SalaryTax {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        double salary, rate = 0, tax, netsal;
        String gender;
        System.out.println("Enter the Amount of salary and gender.\nUse 'F' for female, and 'M' for male.");
        System.out.print("Gender = ");
        gender = input.next().toUpperCase();
        System.out.print("Salary = ");
        salary = input.nextDouble();
        switch (gender) {
            case "M":
                if (salary <= 30000) {
                    rate = 0.13;
                }
                else {
                    rate = 0.15;
                }   break;
            case "F":
                if (salary <= 20000) {
                    rate = 0.12;
                }
                else {
                    rate = 0.14;
            }   break;
        }
        tax = salary * rate;
        netsal = salary - tax;
        System.out.println("Tax amount = "+tax);
        System.out.println("Net salary = "+netsal);
    }
}
