/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.util.*;

public class FizzBuzz {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("\nEnter range of numbers");
        System.out.print("\nStart : ");
        int start = input.nextInt();

        do {
            start++;
        } while (start < 1);

        System.out.print("Stop : ");
        int stop = input.nextInt();

        for (int i = start; i <= stop; i++) {

            if (i % 3 == 0 && i % 5 != 0) {
                System.out.println("Fizz");
            } else if (i % 5 == 0 && i % 3 != 0) {
                System.out.println("Buzz");
            } else if (i % 3 == 0 && i % 5 == 0) {
                System.out.println("FizzBuzz");
            } else {
                System.out.println(i);
            }

        }

    }

}
