/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author dylo
 */
import java.util.*;

public class FizzBuzz {

    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        System.out.println("Enter Range of numbers");
        System.out.print("\nStart : ");
        int start = input.nextInt();

        while (start < 1) {
            start++;
        }

        System.out.print("Stop : ");
        int stop = input.nextInt();

        System.out.print("\n");

        for (int i = start; i <= stop; i++) {

            if (i % 3 == 0 && i % 5 != 0) {
                System.out.println(i + ": Fizz");
            } else if (i % 5 == 0 && i % 3 != 0) {
                System.out.println(i + ": Buzz");
            } else if (i % 3 == 0 && i % 5 == 0) {
                System.out.println(i + ": FizzBuzz");
            } else {
                System.out.println(i + ": " + i);
            }

        }

        System.out.print("\n");

    }

}
