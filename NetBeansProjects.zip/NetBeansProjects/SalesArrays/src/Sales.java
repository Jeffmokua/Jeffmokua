/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.util.*;

public class Sales {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double[] arr = new double[]{14, 9, 78, 89, 9};
        arr = new double[10];
        String name = null, day;
        double sales = 0;
        int counter;
        int total = 0;
        for (counter = 0; counter < 5; counter++) {
            System.out.println("enter the name" + (counter + 1));
            name = sc.next();
        }
        for (counter = 0; counter < 5; counter++) {
            System.out.println("enter the sales" + (counter + 1));
            sales = sc.nextDouble();
        }
        for (counter = 0; counter < 5; counter++) {
            System.out.println("enter the day" + (counter + 1));
            day = sc.next();
            for (counter = 0; counter < 5; counter++) {
                total += arr[counter];
                System.out.println("name=" + name + "day=" + day + "sales=" + sales + (counter + 1));

            }
        }
    }
}
