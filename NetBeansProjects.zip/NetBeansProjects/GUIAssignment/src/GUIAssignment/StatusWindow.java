/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUIAssignment;

/**
 *
 * @author dylo
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.FlowLayout;
import javax.swing.*;
//status window class
public class StatusWindow extends JFrame {

    private final JLabel lbl4;
    private final JLabel lbl5;
    private final JTextField txtdia;
    private final JTextField txtsys;
    private final JButton btnstat;
    private final JLabel lbl6;

    public StatusWindow() {
        super("BP Status Window");
        setLayout(new FlowLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 500);
        setVisible(true);
        lbl4 = new JLabel("Diastolic");
        add(lbl4);
        txtdia = new JTextField(10);
        add(txtdia);
        lbl5 = new JLabel("Systolic");
        add(lbl5);
        txtsys = new JTextField(10);
        add(txtsys);
        btnstat = new JButton("BP Status");
        add(btnstat);
        lbl6 = new JLabel();
        add(lbl6);

        Stat st = new Stat();
        btnstat.addActionListener(st);
    }

    private class Stat implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            String status = null;
            double diastolic, systolic;
            systolic = Double.parseDouble(txtsys.getText());
            diastolic = Double.parseDouble(txtdia.getText());

            if (event.getSource() == btnstat) {

                if (systolic < 120 && diastolic < 80) {
                    status = "Normal";
                } else if (systolic < 140 && diastolic < 90) {
                    status = "Hypertension";
                } else if (systolic > 139 && diastolic > 89) {
                    status = "High";
                }
                lbl6.setText("BP Status: " + status);
            }
        }
    }
}
