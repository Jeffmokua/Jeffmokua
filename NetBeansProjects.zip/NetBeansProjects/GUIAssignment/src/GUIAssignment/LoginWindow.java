/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author dylo
 */
package GUIAssignment;
//login window class

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.FlowLayout;
import javax.swing.*;

public class LoginWindow extends JFrame {

    private final JLabel lbl1;
    private final JLabel lbl2;
    private final JLabel lbl3;
    private final JComboBox cboacc;
    private final JTextField txtuser;
    private final JPasswordField pswdpass;
    private final JButton btnlog;
    private final JButton btnclear;
    private final String[] acc = {"Doctor", "Nurse", "Nurse Aid"};

    public LoginWindow() {
        super("Login Window");
        setLayout(new FlowLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 500);
        lbl1 = new JLabel("Account Type");
        add(lbl1);
        cboacc = new JComboBox(acc);
        add(cboacc);
        lbl2 = new JLabel("Username");
        add(lbl2);
        txtuser = new JTextField(10);
        add(txtuser);
        lbl3 = new JLabel("Password");
        add(lbl3);
        pswdpass = new JPasswordField(10);
        add(pswdpass);
        btnlog = new JButton("Login");
        add(btnlog);
        btnclear = new JButton("Cancel");
        add(btnclear);

        Logger logg = new Logger();
        btnlog.addActionListener(logg);
        btnclear.addActionListener(logg);
    }

    private class Logger implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            String username, password;
            username = txtuser.getText();
            password = pswdpass.getText();
            if (event.getSource() == btnlog) {
                if ((username.equals("dalmas") && password.equals("dalmas")) || (username.equals("vitalis") && (password.equals("vitalis")))) {
                    dispose();
                    new StatusWindow().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Incorrect Username or Password.");
                    txtuser.setText(null);
                    pswdpass.setText(null);
                }
            } else {
                txtuser.setText(null);
                pswdpass.setText(null);
            }
        }
    }

    public static void main(String[] args) {

        LoginWindow log = new LoginWindow();
        log.setVisible(true);

    }
}
