/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SystolicDiastolic;

/**
 *
 * @author dylo
 */
//class LoginScreen; Houses Login window
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.FlowLayout;
import javax.swing.*;

public class LoginScreen extends JFrame { //main class

    private final JLabel lbl1;
    private final JLabel lbl2;
    private final JLabel lbl3;
    private final JComboBox cboaccount;
    private final JTextField txtusername;
    private final JPasswordField pswdpassword;
    private final JButton btnlogin;
    private final JButton btncancel;
    String[] account = {"Doctor", "Nurse", "Nurse Aid"};

    public LoginScreen() { //default constructor
        super("LOGIN SCREEN");
        setLayout(new FlowLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1050, 400);
        lbl1 = new JLabel("Account Type");
        add(lbl1);
        cboaccount = new JComboBox(account);
        add(cboaccount);
        lbl2 = new JLabel("Username");
        add(lbl2);
        txtusername = new JTextField(10);
        add(txtusername);
        lbl3 = new JLabel("Password");
        add(lbl3);
        pswdpassword = new JPasswordField(10);
        add(pswdpassword);
        btnlogin = new JButton("Login");
        add(btnlogin);
        btncancel = new JButton("Cancel");
        add(btncancel);

        Check ck = new Check(); //object of the inner class created
        btnlogin.addActionListener(ck);
        btncancel.addActionListener(ck);
    }   //constructor ends here

    private class Check implements ActionListener { //inner class

        @Override
        public void actionPerformed(ActionEvent event) {
            String username, password;
            username = txtusername.getText();
            password = pswdpassword.getText();
            if (event.getSource() == btnlogin) {
                if ((username.equals("dalmas") && password.equals("dalmas")) || (username.equals("vitalis") && (password.equals("vitalis"))) || (username.equals("brighton") && password.equals("brighton")) || (username.equals("linux") && password.equals("linux")) || (username.equals("essy") && password.equals("essy")) || (username.equals("barry") && password.equals("barry")) || (username.equals("sharon") && password.equals("sharon")) || (username.equals("filo") && password.equals("filo"))) {
 
                    new StatusScreen().setVisible(true); //opens Status window///////
                    dispose();  //closes Login (current) window
                } else {
                    JOptionPane.showMessageDialog(null, "Incorrect Username or Password. Please try again");
                    txtusername.setText(null);
                    pswdpassword.setText(null);
                }
            } else {
                txtusername.setText(null);
                pswdpassword.setText(null);
            }
        }
    } //inner class ends here

    public static void main(String[] args) { //main method
        
        LoginScreen lgnscrn = new LoginScreen();
        lgnscrn.setVisible(true);

    }   //main method ends here
}   //main class ends here
