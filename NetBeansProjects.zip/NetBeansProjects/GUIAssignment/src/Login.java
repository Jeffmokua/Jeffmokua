/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.FlowLayout;
import javax.swing.*;

public class Login extends JFrame {

    private JLabel lbl1;
    private JLabel lbl2;
    private JLabel lbl3;
    private JComboBox cboaccount;
    private JTextField txtusername;
    private JTextField txtpassword;
    private JButton btnlogin;
    private JButton btncancel;

    private JLabel lbl4;
    private JLabel lbl5;
    private JTextField txtdiastolic;
    private JTextField txtsystolic;
    private JButton btnststus;
    private JLabel lbl6;

    public Login() {

        super("LOGIN WINDOW");
        setLayout(new FlowLayout());
        lbl1 = new JLabel("Account Type");
        add(lbl1);
        cboaccount = new JComboBox();
        add(cboaccount);
        lbl2 = new JLabel("Username");
        add(lbl2);
        txtusername = new JTextField(10);
        add(txtusername);
        lbl3 = new JLabel("Password");
        add(lbl3);
        txtpassword = new JTextField(10);
        add(txtpassword);
        btnlogin = new JButton("Login");
        add(btnlogin);
        btncancel = new JButton("Cancel");
        add(btncancel);
    }

    private abstract class Check implements ActionListener {

        public void actionPerformed(ActionEvent event) {
            if (event.getSource() == btnlogin) {

            } else {
                txtusername.setText("");
                txtpassword.setText("");
            }
        }
    }

    private abstract class BPStatus extends JFrame {

    }
}
