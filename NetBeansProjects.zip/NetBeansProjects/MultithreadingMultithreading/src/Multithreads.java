/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import javax.swing.JOptionPane;

public class Multithreads extends Thread {

    public int a, b;

    public Multithreads() {
        a = Integer.parseInt(JOptionPane.showInputDialog("Enter the first integer"));
        b = Integer.parseInt(JOptionPane.showInputDialog("Enter the second integer"));
    }

    public void render() {
        Thread addition = new Thread(new Runnable() {
            int addition;

            @Override
            public void run() {
                System.out.println("Addition has started");
                addition = a + b;
                System.out.println("Addition is running");
                System.out.println("Addition = " + addition);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex1) {
                    System.out.println("Addition is interrupted");
                }
                {
                    System.out.println("Addition is executed");
                }

            }
        });
        Thread multiplication = new Thread(new Runnable() {
            int multiplication;

            @Override
            public void run() {
                System.out.println("Mutiplication has started");
                multiplication = a * b;
                System.out.println("Mutiplication is running");
                System.out.println("Mutiplication = " + multiplication);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex2) {
                    System.out.println("Multiplication is interrupted");
                }
                {
                    System.out.println("Multiplication is executed");
                }
            }

        });
        Thread division = new Thread(new Runnable() {
            int division;

            @Override
            public void run() {
                System.out.println("Division has started");
                division = a / b;
                System.out.println("Division is running ");
                System.out.println("Division = " + division);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex1) {
                    System.out.println("Division is interrupted");
                }
                {
                    System.out.println("Division is executed");
                }
            }
        });
        Thread subtraction = new Thread(new Runnable() {
            int subtraction;

            @Override
            public void run() {
                System.out.println("Subtraction has started");
                subtraction = a - b;
                System.out.println("Subtraction is running ");
                System.out.println("Subtraction = " + subtraction);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ex1) {
                    System.out.println("Subtraction is interrupted");
                }
                {
                    System.out.println("Subtraction is executed");
                }
            }
        });
        addition.start();
        multiplication.start();
        division.start();
        subtraction.start();
    }

    public static void main(String[] args) {
        Multithreads multi = new Multithreads();
        multi.render();
    }
}
