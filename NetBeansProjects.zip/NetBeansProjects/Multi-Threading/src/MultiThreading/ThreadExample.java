/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MultiThreading;

/**
 *
 * @author dylo
 */
public class ThreadExample extends Thread {

    String threadname;

    public ThreadExample(String name) {
        threadname = name;
        System.out.println(threadname + ": Created");
    }

    public void run() {
        System.out.println(threadname + ": Started");
        try {
            for (int i = 3; i > 0; i--) {
                System.out.println(threadname + ": Running " + i);
                System.out.println(threadname + ": Sleeping");
                Thread.sleep(1000);
                System.out.println(threadname + ": Has risen");
            }
        } catch (InterruptedException ex1) {
            System.out.println(threadname + ": Interrupted");
        }
        System.out.println(threadname + ": Terminated");
    }

    public static void main(String[] args) {
        ThreadExample t1 = new ThreadExample("Thread 1");
        ThreadExample t2 = new ThreadExample("Thread 2");
        t1.start();
        t2.start();
    }
}
