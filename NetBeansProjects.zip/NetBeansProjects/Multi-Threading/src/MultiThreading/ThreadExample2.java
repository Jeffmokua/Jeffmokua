/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MultiThreading;

/**
 *
 * @author dylo
 */
public class ThreadExample2 implements Runnable{
    String threadname;
    public ThreadExample2(String name){
        threadname = name;
        System.out.println(threadname+": Created");
    }
    
    public void run(){
        System.out.println(threadname+": Started");
        try {
           for(int i=3;i>0;i--){
               System.out.println(threadname+": Running"+i);
               System.out.println(threadname+": Sleeping");
               Thread.sleep(500);
               System.out.println(threadname+": Has risen");
           }
        }catch(InterruptedException ex1){
            System.out.println(threadname+": Interrupted");
        }
        System.out.println(threadname+": Terminated");
    }
    
    public static void main(String[] args){
        ThreadExample2 t2 = new ThreadExample2("Thread 2");
        ThreadExample2 t1 = new ThreadExample2("Thread 1");
        Thread th1 = new Thread(t1);
        Thread th2 = new Thread(t2);
        th1.start();
        th2.start();
    }
}
