/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.util.*;
public class Meteo {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        String[]name=new String[7];
        int [][]reading=new int[7][3];
        double average,sum;
        for(int i=1;i<=6;i++){
            System.out.println("input your day"+i);
            name[i]=input.next();
            for(int j=1;j<=6;j++){
                System.out.println("ïnput the reading"+j);
                reading[i][j]=input.nextInt();
            }
        }
         for(int i=1;i<=6;i++){
            System.out.println("name="+name);
            name[i]=input.next();
            sum=0;
            for(int j=1;j<=6;j++){
                System.out.println("reading="+reading);
             
             sum=sum+reading[i][j];
             
            }
            average=sum/6;
            System.out.println("average="+average);
        }
         System.out.println("");
    }
}
