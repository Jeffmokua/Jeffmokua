/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.util.*;
public class Name {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.println("Hello there");
        System.out.println("Please enter your name");
        String fstname, lstname;
        System.out.print("First Name : ");
        fstname = input.next();
        System.out.print("Last name : ");
        lstname = input.next();
        System.out.println("Thank you!\nWe will now print out your full name");
        System.out.println("Your full name is "+fstname+" "+lstname);
        System.out.println("JAVA is the Programming language of choice.\nJAVA is the best!");
        System.out.println("This program was built by dylo");
    }
}
