/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
//
import java.util.*;
public class Person {
    Scanner input = new Scanner(System.in);
    int age;
    String name;
    String address;
    public Person(){ //this is a default constructor; assigning default values to objects
        System.out.println("An object is created");
        age = 20;
        name = "Ayieko";
        address = "Kisumu Dala";
    }
    public Person(int age, String name, String address){ //this is a parametized constructor; assigning parametized values to objects
        this.age = age;
        this.name = name;
        this.address = address;
    }
    public void getdetails(){ //this is a method used to input/ specify values
        System.out.println("Enter the name of a person");
        name = input.next();
        System.out.println("Enter the age of a person");
        age = input.nextInt();
        System.out.println("Enter the address of a person");
        address = input.next();
    }
    public static void main(String[] args){        
        Person p1 = new Person();
        Person p2 = new Person(30, "Kadoto", "Maragoli");
        //p2.getdetails();
        
        System.out.println("1st PERSON DETAILS\nName : "+p1.name+"\nAge : "+p1.age+"\nAddress : "+p1.address);
        System.out.println("2nd PERSON DETAILS\nName : "+p2.name+"\nAge : "+p2.age+"\nAddress : "+p2.address);
    }
}
