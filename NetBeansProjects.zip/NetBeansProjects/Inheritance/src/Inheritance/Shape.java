/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inheritance;

/**
 *
 * @author dylo
 */
public abstract class Shape {
    protected double area, perimeter;
    public abstract void getdimensions();
    public abstract void computearea();
    public abstract void computeperimeter();
    public void print(){
        System.out.println("Area = "+area+"\nPerimeter = "+perimeter);
    }
}
