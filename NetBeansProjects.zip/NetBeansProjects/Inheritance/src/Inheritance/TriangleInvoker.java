/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inheritance;

/**
 *
 * @author dylo
 */
/*public abstract class TriangleInvoker implements Polygon {
   public  static void main(String[] args){
       Polygon poly = new Polygon();
       
       poly.getdimensions();
       poly.computearea();
       poly.computeperimeter();
       poly.print();
   }
}*/
