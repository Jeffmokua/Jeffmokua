/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inheritance;

/**
 *
 * @author dylo
 */
public interface Polygon {
    public abstract void getdimensions();
    public abstract void computearea();
    public abstract void computeperimeter();
    public abstract void print();
    
}
