/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inheritance;

/**
 *
 * @author dylo
 */
import java.util.*;
public class Circle extends Shape {
    private int radius;
    @Override
    public void getdimensions(){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the Radius");
        radius = input.nextInt();
    }
    @Override
    public void computearea(){
        area = Math.PI * Math.pow(radius, 2);
    }
    @Override
    public void computeperimeter(){
        perimeter = Math.PI * radius * 2;
    }
}
