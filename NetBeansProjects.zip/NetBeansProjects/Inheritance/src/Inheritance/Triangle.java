/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inheritance;

/**
 *
 * @author dylo
 */
import java.util.*;
public abstract class Triangle implements Polygon{
    Scanner input = new Scanner(System.in);
    private double base, height, hyp;
    private double area, perimeter;
    @Override
    public void getdimensions(){
        System.out.println("Enter base");
        base = input.nextDouble();
        System.out.println("Enter height");
        height = input.nextDouble();
        hyp = Math.sqrt(Math.pow(base, 2)+Math.pow(height, 2));
    }
    @Override
    public void computearea(){
        area = 0.5*base*height;
    }
    @Override
    public void computeperimeter(){
        perimeter = base+height+hyp;
    }
    @Override
    public void print(){
        System.out.println("Area = "+area+"\nPerimeter = "+perimeter+"\n");
    }
     
     
}
