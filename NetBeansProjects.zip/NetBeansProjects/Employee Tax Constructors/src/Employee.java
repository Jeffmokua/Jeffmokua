/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.util.*;
public class Employee {
    Scanner input = new Scanner(System.in);
    double salary = 0;
    String gender;
   
    //double netsalary = 0, allowance = 0, rate = 0, taxamount = 0, totaltaxable = 0;
    //String name;
    
    
    public Employee(){ //First constructor.
        System.out.println("An object is created");
        salary = 0;
        gender = " ";
    }
    public Employee(double sal, String gen){ //second constructor; it is a parameterized constructor; i.e double sal, string gen,,
        salary = sal;
        gender = gen;
    }
    
    //You can just skip this part for now
    
    /*
    public void getdetails(){
        Scanner input = new Scanner(System.in);
        System.out.println("This program uses Static Member Functions");
        System.out.println("Enter the name of the employee");
        System.out.print("Name : ");
        name = input.next();
        System.out.println("Enter the basic salary");
        System.out.print("Basic Salary : Ksh. ");
        salary = input.nextDouble();
        System.out.println("Enter total allowance\nIf there is no allowance, enter value 0");
        System.out.print("Allowance : Ksh. ");
        allowance = input.nextDouble();
        System.out.println("Enter the gender of the employee;\n'F' for female or 'M' for male");
        System.out.print("Gender : ");
        gender = input.next().toUpperCase();        
    }
    public void compute(){
        switch (gender) {
            case "F":
                 if (salary >= 10000){
                     rate = 0.14;
                 }
                 else{
                     rate = 0.1;
                 }  break;
            case "M":
                 if (salary >= 10000){
                     rate = 0.15;
                 }
                 else{
                     rate = 0.12;
                 }  break;                        
        }
        totaltaxable = salary + allowance;
        taxamount = rate * totaltaxable;
        netsalary = totaltaxable - taxamount; 
    }
    public void output(){
        if (!gender.equals("F") && !gender.equals("M")){
            System.out.println("Sorry. The program could not compute the net salary\nThe gender entered is invalid");
        }
        else {
            System.out.println("Name : "+name);
            System.out.println("Total Taxable Income : KSh. "+totaltaxable);
            System.out.println("Tax Amount : KSh. "+taxamount);
            System.out.println("Net Salary : KSh. "+netsalary);
        }
    } 
    */
    
    public static void main(String[] args){ //main method starts here
        //Employee.getdetails();
        //Employee.compute();
        //Employee.output();
        Employee emp1 = new Employee(); //First object is created for the FIRST CONSTRUCTOR
        Employee emp2 = new Employee(5000, "M"); //Second object is created for the SECOND CONSTRUCTOR and initilized with values
        Employee emp3 = new Employee(3000, "F"); //Third object is created for the SECOND CONSTRUCTOR and initilized with values
        System.out.println("1st EMPLOYEE DETAILS\nSalary : "+emp1.salary+"\nGender : "+emp1.gender); //Here, Salary and Gender will be initilized with default values i.e. Salary with 0, Gender with ' ' (a space)
        System.out.println("2nd EMPLOYEE DETAILS\nSalary : "+emp2.salary+"\nGender : "+emp2.gender); //Here, Salary and Gender will be initilized with Specified values i.e. Salary with 5000, Gender with M
        System.out.println("3rd EMPLOYEE DETAILS\nSalary : "+emp3.salary+"\nGender : "+emp3.gender); //Here, Salary and Gender will be initilized with Specified values i.e. Salary with 3000, Gender with F
    }
}
