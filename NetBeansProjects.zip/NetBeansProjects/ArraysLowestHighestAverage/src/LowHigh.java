/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.util.*;

public class LowHigh {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int marks[] = new int[10];
        int lowest, highest, i;
        double average;
        int sum = 0;
        for (i = 0; i < 10; i++) {
            System.out.println("Enter the marks of student " + (i + 1));
            marks[i] = input.nextInt();
            sum = sum + marks[i];
        }
        average = sum / 10;
        lowest = marks[0];
        highest = marks[0];
        for (i = 0; i < 10; i++) {
            if (marks[i] < lowest) {
                lowest = marks[i];
            }
            if (marks[i] > highest) {
                highest = marks[i];
            }
        }
        System.out.println("Highest = " + highest);
        System.out.println("Lowest = " + lowest);
        System.out.println("Average = " + average);
    }
}
