/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
//import java.util.Scanner;

public class Meteorology {

    private String sitename;
    private final int[][] reading;

    public Meteorology(String name, int[][] readingArray) {
        sitename = name;
        reading = readingArray;
    }

    public void setsitename(String name) {
        sitename = name;
    }

    public String getsitename() {
        //Scanner input = new Scanner(System.in);
        //sitename = input.next();
        return sitename;
    }

    public void print() {
        System.out.println("Before anything, I want to let y'all know that this is my very first Java program");
        System.out.printf("welcome to the metelologist daily reading for\n%s\n\n", getsitename());
    }

    public void processreadings() {
        printme();
        System.out.printf("\n%s %d\n%s%d\n\n", "The lowest reading in is ", getminimum(), "\nThe highest reading is ", getmaximum());
        outputform();
    }

    public int getminimum() {
        int lowreading = reading[0][0];
        for (int[] dayreading : reading) {
            for (int readings : dayreading) {
                if (readings < lowreading) {
                    lowreading = readings;
                }
            }
        }
        return lowreading;
    }

    public int getmaximum() {
        int highreading = reading[0][0];
        for (int[] dayreading : reading) {
            for (int readings : dayreading) {
                if (readings > highreading) {
                    highreading = readings;
                }
            }
        }
        return highreading;
    }

    public double getaverage(int[] setofreadings) {
        int total = 0;
        for (int readings : setofreadings) {
            total += readings;
        }
        return (double) total / setofreadings.length;
    }

    public void outputform() {
        System.out.println("Graph illustrating overall readings:");
        int[] mimic = new int[11];
        for (int[] dayreading : reading) {
            for (int readings : dayreading) {
                ++mimic[readings / 10];
            }
        }
        for (int man = 0; man < mimic.length; man++) {
            if (man == 10) {
                System.out.printf("%5d:", 100);
            } else {
                System.out.printf("%02d-%02d:", man * 10, man * 10 + 9);
            }
            for (int sun = 0; sun <= mimic[man]; sun++) {
                System.out.print("#");
            }
            System.out.println();
        }
    }

    public void printme() {
        System.out.println("Readings are:\n");
        System.out.print("     ");
        for (int read = 0; read < reading[0].length; read++) {
            System.out.printf("\tReading %d", read + 1);
        }
        System.out.println("\tAverage");
        for (int days = 0; days < reading.length; days++) {
            System.out.printf("Day %2d", days + 1);
            for (int tan : reading[days]) {
                System.out.printf("%6d", tan);
            }
            double average = getaverage(reading[days]);
            System.out.printf("%9.2f\n", average);
        }
    }

    public static void main(String[] args) {
        int[][] readingArray = {{10, 20, 30},
        {35, 54, 34}, {44, 33, 45}, {44, 33, 44}, {43, 65, 66}, {78, 98, 54}, {55, 67, 23}, {45, 65, 55}, {44, 44, 44}, {55, 55, 55}, {55, 55, 34}};
        Meteorology met = new Meteorology("DM Networks Meteorology Department", readingArray);
        met.print();
        met.processreadings();
    }
}
