/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.util.*;

public class Quadratic {

    public static void main(String[] args) {
        double a;
        double b;
        double c;
        double root1, root2;
        Scanner input;
        input = new Scanner(System.in);
        System.out.println("Enter the value of a, b, and c");
        System.out.print("a : ");
        a = input.nextDouble();
        System.out.print("b : ");
        b = input.nextDouble();
        System.out.print("c : ");
        c = input.nextDouble();
        double discriminant;
        discriminant = b * b - 4 * a * c;
        System.out.println("Discriminant = " + discriminant);
        if (discriminant > 0) {
            root1 = -b + Math.sqrt(b * b - 4 * a * c) / 2 * a;
            root2 = -b - Math.sqrt(b * b - 4 * a * c) / 2 * a;
            System.out.println("Root 1 = " + root1 + ", Root 2 = " + root2);
        } else if (discriminant == 0) {
            root1 = root2 = b / 2 * a;
            System.out.println("Root = " + root1);
        } else {
            System.out.println("There are no roots");
        }
    }
}
