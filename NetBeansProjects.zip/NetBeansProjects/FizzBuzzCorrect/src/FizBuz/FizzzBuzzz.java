/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FizBuz;

/**
 *
 * @author dylo - 4/6/'20
 */
import java.util.*;

public class FizzzBuzzz {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter Range of numbers");
        System.out.print("\nStart : ");
        int start = input.nextInt();

        while (start < 1) {
            start++;
        }

        System.out.print("Stop : ");
        int stop = input.nextInt();

        System.out.println("\nComputing...\n");

        for (int i = start; i <= stop; i++) {
            String output = "";
            if (i % 3 == 0) {
                output += "Fizz";
            }
            if (i % 5 == 0) {
                output += "Buzz";
            } else {
            }
            if ("".equals(output)) {
                System.out.print(i);
            }
            System.out.println(output);
        }
    }
}

