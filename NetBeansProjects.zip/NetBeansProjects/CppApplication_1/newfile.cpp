/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include<iostream>
using namespace std;

/*Class Employee*/
class Employee { //class employee starts here

private: //declaration of the member variables
    string name;
    double sal, allowance, rate, tax, netsal;
    char gender;


public:

    void input() { //this member function is used to input the details needed
        cout << "Enter the name of the employee : ";
        cin>>name;
        cout << "Enter the Basic Salary of the employee : ";
        cin>>sal;
        cout << "Enter the Total Allowances of the employee : ";
        cin>>allowance;
        cout << "Enter the gender of the employee (F - Female, M - Male) : ";
        cin>>gender;
    }


public:

    void compute() { //this member function performs the necessary operations
        if (gender == 'F' || gender == 'f') {
            if (sal < 15000) {
                rate = 0.12;
            } else if (sal >= 15000) {
                rate = 0.14;
            }
        }
        else if (gender == 'M' || gender == 'm') {
            if (sal < 14000) {
                rate = 0.13;
            } else if (sal >= 14000) {
                rate = 0.15;
            }
        }

        tax = rate * (sal + allowance);
        netsal = sal - tax;
    }

public:

    void output() { //this member function is used to output
        cout << "\n\nEmployee : " << name << endl;
        cout << "\nTax Amout = " << tax << endl;
        cout << "Net Salary = " << netsal << endl;
    }

}; //class Employee ends here

int main() { //main method begins here
    Employee emp; //an object is created for the class

    emp.input(); //here, the object is used to call the input function in the class
    emp.compute(); ////here, the object is used to call the compute function in the class
    emp.output(); ////here, the object is used to call the output function in the class

    return 0;
} //main method ends here