/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import javax.swing.JOptionPane;

public class MAssignment extends Thread {

    public int a, b;

    public MAssignment() {
        a = Integer.parseInt(JOptionPane.showInputDialog("Enter the first integer"));
        b = Integer.parseInt(JOptionPane.showInputDialog("Enter the second integer"));
    }

    public void getthem() {
        Thread add = new Thread(new Runnable() {
            int add;

            @Override
            public void run() {
                System.out.println("Addition has started");
                add = a + b;
                System.out.println("Addition is running");
                System.out.println("Addition = " + add);
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException ex1) {
                    System.out.println("Addition is interrupted");
                }
                {
                    System.out.println("Addition is executed");
                }

            }
        });
        Thread muti = new Thread(new Runnable() {
            int muti;

            @Override
            public void run() {
                System.out.println("Mutiplication has started");
                muti = a * b;
                System.out.println("Mutiplication is running");
                System.out.println("Mutiplication = " + muti);
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException ex2) {
                    System.out.println("Multiplication is interrupted");
                }
                {
                    System.out.println("Multiplication is executed");
                }
            }

        });
        Thread div = new Thread(new Runnable() {
            int div;

            @Override
            public void run() {
                System.out.println("Division has started");
                div = a / b;
                System.out.println("Division is running ");
                System.out.println("Division = " + div);
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException ex1) {
                    System.out.println("Division is interrupted");
                }
                {
                    System.out.println("Division is executed");
                }
            }
        });
        Thread sub = new Thread(new Runnable() {
            int sub;

            @Override
            public void run() {
                System.out.println("Subtraction has started");
                sub = a - b;
                System.out.println("Subtraction is running ");
                System.out.println("Subtraction = " + sub);
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException ex1) {
                    System.out.println("Subtraction is interrupted");
                }
                {
                    System.out.println("Subtraction is executed");
                }
            }
        });
        add.start();
        sub.start();
        muti.start();
        div.start();
    }

    public static void main(String[] args) {
        MAssignment th = new MAssignment();
        th.getthem();
    }
}
