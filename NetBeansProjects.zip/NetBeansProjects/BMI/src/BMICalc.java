/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.util.*;
public class BMICalc {
    public static void main(String[] args){
        Scanner inputing = new Scanner (System.in);
        System.out.println("Enter weight");
        double weight = inputing.nextDouble();
        System.out.println("Enter height");
        double height = inputing.nextDouble();
        double bmi;
        bmi = weight / Math.pow(height, 2);
        System.out.println("BMI value = "+bmi);
    }
}
