/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.FlowLayout;
import javax.swing.*;

public class HardCode extends JFrame {

    private final JLabel lbl1;
    private final JLabel lbl2;
    private final JLabel lbl3;
    private final JLabel lbl4;
    private final JLabel lbl5;
    private final JTextField txtname;
    private final JTextField txtweight;
    private final JTextField txtheight;
    private final JTextField txtvalue;
    private final JTextField txtstatus;
    private final JButton btndetermine;
    private final JButton btncancel;

    public HardCode() {  //default constructor
        super("BMI CALCULATOR");
        setLayout(new FlowLayout());
        lbl1 = new JLabel("Name");
        add(lbl1);
        txtname = new JTextField(10);
        add(txtname);
        lbl2 = new JLabel("Weight (Kg)");
        add(lbl2);
        txtweight = new JTextField(10);
        add(txtweight);
        lbl3 = new JLabel("Height (M)");
        add(lbl3);
        txtheight = new JTextField(10);
        add(txtheight);
        btndetermine = new JButton("Determine");
        add(btndetermine);
        lbl4 = new JLabel("BMI Value");
        add(lbl4);
        txtvalue = new JTextField(10);
        add(txtvalue);
        lbl5 = new JLabel("Status");
        add(lbl5);
        txtstatus = new JTextField(10);
        add(txtstatus);
        btncancel = new JButton("Cancel");
        add(btncancel);

        Calculate c1 = new Calculate(); //object of the inner class created
        btndetermine.addActionListener(c1);
        btncancel.addActionListener(c1);

    }

    public static void main(String[] args) { //main method
        HardCode h1 = new HardCode();
        h1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        h1.setSize(1050, 650);
        h1.setVisible(true);
    }

    private class Calculate implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            if (event.getSource() == btndetermine) {
                String name, status;
                double weight, height, BMI;
                weight = Double.parseDouble(txtweight.getText());
                height = Double.parseDouble(txtheight.getText());
                BMI = weight / Math.pow(height, 2);
                if (BMI < 18.5) {
                    status = "Underweight";
                } else if (BMI < 24.5) {
                    status = "Normal Weight";
                } else if (BMI < 29.9) {
                    status = "Overweight";
                } else {
                    status = "Obese";
                }
                txtvalue.setText(Double.toString(BMI));
                txtstatus.setText(status);
            } else {
                txtname.setText("");
                txtweight.setText("");
                txtheight.setText("");
                txtvalue.setText("");
                txtstatus.setText("");

            }
        }
    }
}
