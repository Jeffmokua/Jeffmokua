/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
public class Dylos {

    private String sitename;
    private int[][] reading;

    public Dylos(String name, int[][] readingArray) {
        sitename = name;
        reading = readingArray;
    }

    public void setsitename(String name) {
        sitename = name;
    }

    public String getsitename() {
        return sitename;
    }

    public void print() {
        System.out.printf("welcome to the metelologist daily reading for\n%s!\n\n", getsitename());
    }

    public void processreadings() {
        printme();
        System.out.printf("\n%s %d\n%s%d\n\n", "lowestreading in metelologist is", getminimum(), "highest reading is", getmaximum());
        outputform();
    }

    public int getminimum() {
        int lowreading = reading[0][0];
        for (int[] dayreading : reading) {
            for (int readings : dayreading) {
                if (readings < lowreading) {
                    lowreading = readings;
                }
            }
        }
        return lowreading;
    }

    public int getmaximum() {
        int highreading = reading[0][0];
        for (int[] dayreading : reading) {
            for (int readings : dayreading) {
                if (readings > highreading) {
                    highreading = readings;
                }
            }
        }
        return highreading;
    }

    public double getaverage(int[] setofreadings) {
        int total = 0;
        for (int readings : setofreadings) {
            total += readings;
        }
        return (double) total / setofreadings.length;
    }

    public void outputform() {
        System.out.println("overall readings:");
        int[] mimic = new int[11];
        for (int[] dayreading : reading) {
            for (int readings : dayreading) {
                ++mimic[readings / 10];
            }
        }
        for (int man = 0; man < mimic.length; man++) {
            if (man == 10) {
                System.out.printf("%5d:", 100);
            } else {
                System.out.printf("%02d-%02d:", man * 10, man * 10 + 9);
            }
            for (int sun = 0; sun <= mimic[man]; sun++) {
                System.out.print("#");
            }
            System.out.println();
        }
    }

    public void printme() {
        System.out.println("reading are:\n");
        System.out.print("     ");
        for (int read = 0; read < reading[0].length; read++) {
            System.out.printf("\t reading%d", read + 1);
        }
        System.out.println("average");
        for (int days = 0; days < reading.length; days++) {
            System.out.printf("days%2d", days + 1);
            for (int tan : reading[days]) {
                System.out.printf("%6d", tan);
            }
            double average = getaverage(reading[days]);
            System.out.printf("%9.2f\n", average);
        }
    }

    public static void main(String[] args) {
        int[][] readingArray = {{10, 20, 30}, {35, 54, 34}, {44, 33, 45}, {44, 33, 44}, {43, 65, 66}, {78, 98, 54}, {55, 67, 23}, {45, 65, 55}, {44, 44, 44}, {55, 55, 55}, {55, 55, 34}};
        Dylos bet = new Dylos("mwe", readingArray);
        bet.print();
        bet.processreadings();
    }
}
