/*
 * To change this license header, choose License Headers in Project Properti
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylo
 */
import java.util.*;
public class Sports {
    public static void main (String[] args){
        int A=0,B=0,S=0,F=0,spv=0;
        String vote;
        System.out.println("Enter the letter representing the sport you support");
            System.out.println("A - Atheletics, B - Badminton, S - Swimming, F - Soccer");
            System.out.println("Enter 'Q' to end voting");
        do {
            Scanner spooort = new Scanner (System.in);
            
            vote = spooort.next().toUpperCase();
            if (vote.equals("A")){
                A=A+1;
            }
            else if (vote.equals("B")){
                B=B+1;
            }
            else if (vote.equals("F")){
                F=F+1;
            }
            else if (vote.equals("S")){
                S=S+1;
            }
            else if (vote.equals("Q")){
                //this line prevents Q from being counted as a spoilt vote
            }
            else {
                spv=spv+1;
            }
        } while(!vote.equals("Q"));
        System.out.println("Atheletics = "+A+", Badminton = "+B+", Soccer = "+F+", Swimming = "+S);
        System.out.println("Spoilt votes = "+spv);
        if (A>B&A>S&A>F){
            System.out.println("Most popular sport is Atheletics");
        }
        else if (B>A&B>S&A>F){
            System.out.println("Most popular sport is Badminton");
        }
        else if (S>B&S>A&S>F){
            System.out.println("Most popular sport is Swimming");
        }
        else if (F>B&F>A&F>S){
            System.out.println("Most popular sport is Soccer");
        }
        else {
            System.out.println("About the most popular sport; Either there is a tie, or no one voted any sport");
        }
    }
}
