/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include<iostream>
using namespace std;

class GradingSystem {
private:
    int math = 0, eng = 0, kis = 0, phyc = 0, chem = 0, bio = 0, geog = 0, hist = 0, cre = 0, comp = 0, bus = 0, agric = 0;
    int sci = 0, sci_1 = 0, sci_2 = 0, sci_3 = 0, hum = 0, hum_1 = 0, hum_2 = 0, hum_3 = 0;
    double marks = 0, point = 0, points = 0;
    char grade;
    string name;


public:

    void input() {
        cout << "Full Name : ";
        cin>>name;
        cout << "\n\nMarks are to be entered for the respective Units";
        cout << "\nEnter a 0 for units not taken";
        cout << "\nOnly a minimum of 7 and a maximum of 9 units will be allowed";
        cout << "\nMaths, English, Kiswahili, and Chemistry are compulsory.";
        cout << "\nAt least two sciences (Chemistry, Physics, and Biology) are compulsory. Three sciences is accepted";
        cout << "\nAt least one of the three Humanity units (History, Geography, CRE) should be included";
        cout << "\nThe minimum Marks that can be awarded is 1, and the maximum, 99";

        cout << "\n\nComputation is done as follows";
        cout << "\n\n7 units will be used to determine the points and grade";
        cout << "\nAll the four compulsory units and 3 other units";
        cout << "\nThese 3 units include at least 1 science, and 1 Humanity";
        cout << "\n\nYou will now enter Marks for the respective Units";

        cout << "\n\nMaths : ";
        cin>>math;
        while (math > 99) {
            cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
            cout << "Maths : ";
            cin>>math;
        }
        while (math <= 0) {
            cout << "\nMaths is compulsory\nPlease enter the marks scored\n" << endl;
            cout << "Maths : ";
            cin>>math;

            while (math > 99) {
                cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
                cout << "Maths : ";
                cin>>math;
            }

        }

        cout << "\n\nEnglish : ";
        cin>>eng;
        while (eng > 99) {
            cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
            cout << "English : ";
            cin>>eng;
        }
        while (eng <= 0) {
            cout << "\nEnglish is compulsory\nPlease enter the marks scored\n" << endl;
            cout << "English : ";
            cin>>eng;

            while (eng > 99) {
                cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
                cout << "English : ";
                cin>>eng;
            }

        }

        cout << "\n\nKiswahili : ";
        cin>>kis;
        while (kis > 99) {
            cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
            cout << "Kiswahili : ";
            cin>>kis;
        }
        while (kis <= 0) {
            cout << "\nKiswahili is compulsory\nPlease enter the marks scored\n" << endl;
            cout << "Kiswahili : ";
            cin>>kis;

            while (kis > 99) {
                cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
                cout << "Kiswahili : ";
                cin>>kis;
            }

        }

        cout << "\n\nChemistry : ";
        cin>>chem;
        while (chem > 99) {
            cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
            cout << "Chemistry : ";
            cin>>chem;
        }


        cout << "Physics : ";
        cin>>phyc;
        while (phyc > 99) {
            cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
            cout << "Physics : ";
            cin>>phyc;
        }
        cout << "Biology : ";
        cin>>bio;
        while (bio > 99) {
            cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
            cout << "Biology : ";
            cin>>bio;
        }

        while (chem <= 0 && phyc <= 0 || chem <= 0 && bio <= 0 || phyc <= 0 && bio <= 0) {

            cout << "\nAt least 2 Sciences are compulsory\nPlease enter the marks scored\n" << endl;
            cout << "\n\nChemistry : ";
            cin>>chem;
            while (chem > 99) {
                cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
                cout << "Chemistry : ";
                cin>>chem;
            }
            cout << "Physics : ";
            cin>>phyc;
            while (phyc > 99) {
                cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
                cout << "Physics : ";
                cin>>phyc;
            }
            cout << "Biology : ";
            cin>>bio;
            while (bio > 99) {
                cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
                cout << "Biology : ";
                cin>>bio;
            }

        }

        cout << "Geography : ";
        cin>>geog;
        while (geog > 99) {
            cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
            cout << "Geography : ";
            cin>>geog;
        }
        cout << "History & Government : ";
        cin>>hist;
        while (hist > 99) {
            cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
            cout << "History & Government : ";
            cin>>hist;
        }
        cout << "C.R.E : ";
        cin>>cre;
        while (cre > 99) {
            cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
            cout << "C.R.E : ";
            cin>>cre;
        }

        while (geog <= 0 && hist <= 0 && cre <= 0) {

            cout << "\nAt least 1 Humanity is compulsory\nPlease enter the marks scored\n" << endl;
            cout << "Geography : ";
            cin>>geog;
            while (geog > 99) {
                cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
                cout << "Geography : ";
                cin>>geog;
            }
            cout << "History & Government : ";
            cin>>hist;
            while (hist > 99) {
                cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
                cout << "History & Government : ";
                cin>>hist;
            }
            cout << "C.R.E : ";
            cin>>cre;
            while (cre > 99) {
                cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
                cout << "C.R.E : ";
                cin>>cre;
            }

        }

        cout << "Computer Studies : ";
        cin>>comp;
        while (comp > 99) {
            cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
            cout << "Computer Studies : ";
            cin>>comp;
        }
        while (phyc > 0 && bio > 0 && geog > 0 && hist > 0 && cre > 0 && comp > 0) { //implementing the 7 minimum, 9 maximum rule

            cout << "\nOnly a maximum of 9 units are needed\nPlease enter 0 under the marks of the remaining units\n" << endl;
            cout << "Computer Studies : ";
            cin>>comp;

        }

        cout << "Business : ";
        cin>>bus;
        while (bus > 99) {
            cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
            cout << "Business : ";
            cin>>bus;
        }
        while (phyc > 0 && bio > 0 && geog > 0 && hist > 0 && cre > 0 && bus > 0) { //implementing the 7 minimum, 9 maximum rule

            cout << "\nOnly a maximum of 9 units are needed\nPlease enter 0 under the marks of the remaining units\n" << endl;
            cout << "Business : ";
            cin>>bus;

        }

        cout << "Agriculture : ";
        cin>>agric;
        while (agric > 99) {
            cout << "\nThe highest points that can be scored is 99\nPlease enter the marks scored\n" << endl;
            cout << "Agriculture : ";
            cin>>agric;
        }
        while (phyc > 0 && bio > 0 && geog > 0 && hist > 0 && cre > 0 && agric > 0) { //implementing the 7 minimum, 9 maximum rule

            cout << "\nOnly a maximum of 9 units are required\nPlease enter 0 under the marks of the remaining units\n" << endl;
            cout << "Agriculture : ";
            cin>>agric;

        }



    }

public:

    void compute() {

        if (chem > phyc && chem > bio) {
            sci_1 = chem;
            if (phyc > bio) {
                sci_2 = phyc;
            } else if (bio > phyc) {
                sci_2 = bio;
            }
        } else if (phyc > bio && phyc > chem) {
            sci_1 = phyc;
            if (chem > bio) {
                sci_2 = chem;
            } else if (bio > chem) {
                sci_2 = bio;
            }
        } else if (bio > phyc && bio > chem) {
            sci_1 = bio;
            if (phyc > chem) {
                sci_2 = phyc;
            } else if (chem > phyc) {
                sci_2 = chem;
            }
        }

        sci = sci_1 + sci_2;


        if (geog > hist && geog > cre) {
            hum = geog;
        } else if (hist > geog && hist > cre) {
            hum = hist;
        } else if (cre > geog && cre > hist) {
            hum = cre;
        }


        marks = math + eng + kis + sci + hum + geog + hist + cre + comp + bus + agric;

        /*

                A 	- 12 - 81-99
                A-	- 11 - 76-80
                B+	- 10 - 67-75
                B 	- 9 - 60-66
                B-	- 8 - 55-59
                C+	- 7 - 46-54
                C 	- 6 - 40-45
                C-	- 5 - 
                D+	- 4 - 
                D 	- 3 - 35-39
                D-	- 2 - 30-34
                E 	- 1 - 1-29

         */

        if (math >= 80) {
            point = 12;
        } else if (math >= 70) {
            point = 11;
        } else if (math >= 60) {
            point = 10;
        } else if (math >= 50) {
            point = 9;
        } else if (math >= 40) {
            point = 8;
        }



    }


};

int main() {
    GradingSystem gradeSys;

    gradeSys.input();
    gradeSys.compute();
    //gradeSys.output();

    return 0;
}
