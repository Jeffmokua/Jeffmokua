/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <iostream>
using namespace std;

int main() {

    int i, start, stop;
    cout << "Enter the range of numbers" << endl;
    cout << "Start : ";
    cin>>start;

    if (start == 0) {
        start++;
    }

    cout << "Stop : ";
    cin>>stop;

    for (i = start; i <= stop; i++) {

        if (i % 3 == 0 && i % 5 != 0) {
            cout << "Fizz" << endl;
        } else if (i % 5 == 0 && i % 3 != 0) {
            cout << "Buzz" << endl;
        } else if (i % 3 == 0 && i % 5 == 0) {
            cout << "FizzBuzz" << endl;
        } else {
            cout << i << endl;
        }

    }

    return 0;
}
